#ifndef _COMPLIANCE_IO_H
#define _COMPLIANCE_IO_H
#define RVTEST_IO_INIT
#define RVTEST_IO_WRITE_STR(_SP, _STR)
#define RVTEST_IO_CHECK()
#define RVTEST_IO_ASSERT_GPR_EQ(_S, _R, _I)
#endif