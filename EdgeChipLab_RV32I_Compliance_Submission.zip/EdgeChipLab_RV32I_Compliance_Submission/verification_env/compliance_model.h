#ifndef _COMPLIANCE_MODEL_H
#define _COMPLIANCE_MODEL_H

#define RVMODEL_BOOT \
    .section .text.init; \
    .global _start; \
    _start: \
        la x1, trap_handler; \
        csrrw x0, mtvec, x1; \
        beq x0, x0, _run_test; \
    .align 2; \
    trap_handler: \
        beq x0, x0, trap_handler; \
    _run_test:

#define RVMODEL_HALT \
        la x1, tohost; \
        li x2, 1; \
        sw x2, 0(x1); \
    halt_loop: \
        beq x0, x0, halt_loop;

#define RVMODEL_DATA_BEGIN \
    .section .data.sig; \
    .align 4; \
    .global begin_signature; \
    begin_signature:

#define RVMODEL_DATA_END \
    .align 4; \
    .global end_signature; \
    end_signature: \
    .section .data.tohost; .align 3; .global tohost; tohost: .dword 0; \
    .section .data.fromhost; .align 3; .global fromhost; fromhost: .dword 0;

#define RVMODEL_SET_MSW_INT
#define RVMODEL_CLEAR_MSW_INT
#define RVMODEL_CLEAR_MTIMER_INT
#define RVMODEL_CLEAR_MEXT_INT

#endif