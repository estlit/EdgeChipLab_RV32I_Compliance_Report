import subprocess
import sys
import os
import time

# =====================================================================
# [환경 설정]
# =====================================================================
USE_WSL = True
VIVADO_CMD = r"C:\Xilinx\Vivado\2023.1\bin\vivado.bat" 
PROJECT_PATH = r"D:\CPU_FULL_L\RV32I_v1\RV32I_v1.xpr"   
RTL_SIG_FILE = r"D:\CPU_FULL_L\rtl_sig.mem"            
REPO_DIR = r"D:\CPU_FULL_L\riscv-compliance" 

# 💡 [신규 추가] 공식 제출물을 저장할 디렉토리 설정
SUBMISSION_DIR = r"D:\CPU_FULL_L\RV32I_Compliance_Submission"

def wsl_path(path):
    if not USE_WSL: return path
    p = path.replace("\\", "/")
    if len(p) >= 2 and p[1] == ":":
        p = "/mnt/" + p[0].lower() + p[2:]
    return p

def wrap_cmd(cmd_list):
    return ["wsl"] + cmd_list if USE_WSL else cmd_list

def find_test_environment(base_dir):
    test_files = []
    env_dir = None
    for root, dirs, files in os.walk(base_dir):
        if root.endswith('riscv-test-env'):
            env_dir = root
        if 'rv32i' in root and 'src' in root:
            for file in files:
                if file.endswith('.S'):
                    test_files.append(os.path.join(root, file))
    return test_files, env_dir

def create_compliance_headers():
    model_h = """
#ifndef _COMPLIANCE_MODEL_H
#define _COMPLIANCE_MODEL_H

#define RVMODEL_BOOT \\
    .section .text.init; \\
    .global _start; \\
    _start: \\
        la x1, trap_handler; \\
        csrrw x0, mtvec, x1; \\
        beq x0, x0, _run_test; \\
    .align 2; \\
    trap_handler: \\
        beq x0, x0, trap_handler; \\
    _run_test:

#define RVMODEL_HALT \\
        la x1, tohost; \\
        li x2, 1; \\
        sw x2, 0(x1); \\
    halt_loop: \\
        beq x0, x0, halt_loop;

#define RVMODEL_DATA_BEGIN \\
    .section .data.sig; \\
    .align 4; \\
    .global begin_signature; \\
    begin_signature:

#define RVMODEL_DATA_END \\
    .align 4; \\
    .global end_signature; \\
    end_signature: \\
    .section .data.tohost; .align 3; .global tohost; tohost: .dword 0; \\
    .section .data.fromhost; .align 3; .global fromhost; fromhost: .dword 0;

#define RVMODEL_SET_MSW_INT
#define RVMODEL_CLEAR_MSW_INT
#define RVMODEL_CLEAR_MTIMER_INT
#define RVMODEL_CLEAR_MEXT_INT

#endif
    """
    with open("compliance_model.h", "w", encoding="utf-8") as f: 
        f.write("\n".join(line.rstrip() for line in model_h.strip().splitlines()))
    
    test_h = """
#ifndef _COMPLIANCE_TEST_H
#define _COMPLIANCE_TEST_H
#include "compliance_model.h"
#define RV_COMPLIANCE_HALT RVMODEL_HALT
#define RV_COMPLIANCE_DATA_BEGIN RVMODEL_DATA_BEGIN
#define RV_COMPLIANCE_DATA_END RVMODEL_DATA_END
#define RV_COMPLIANCE_RV32M
#define RV_COMPLIANCE_CODE_BEGIN RVMODEL_BOOT
#define RV_COMPLIANCE_CODE_END
#endif
    """
    with open("compliance_test.h", "w", encoding="utf-8") as f: 
        f.write("\n".join(line.rstrip() for line in test_h.strip().splitlines()))

    io_h = """
#ifndef _COMPLIANCE_IO_H
#define _COMPLIANCE_IO_H
#define RVTEST_IO_INIT
#define RVTEST_IO_WRITE_STR(_SP, _STR)
#define RVTEST_IO_CHECK()
#define RVTEST_IO_ASSERT_GPR_EQ(_S, _R, _I)
#endif
    """
    with open("compliance_io.h", "w", encoding="utf-8") as f: 
        f.write("\n".join(line.rstrip() for line in io_h.strip().splitlines()))

def generate_linker_script():
    script = """
OUTPUT_ARCH(riscv)
ENTRY(_start)
SECTIONS
{
  . = 0x80000000;
  .text : { *(.text) *(.text.init) }
  . = 0x80002000; 
  .data : {
    begin_signature = .; *(.data.sig) end_signature = .;
    . = ALIGN(8);
    tohost = .; *(.data.tohost)
    fromhost = .; *(.data.fromhost)
    *(.data)
    *(.sdata)
  }
}
"""
    with open("link.ld", "w", encoding="utf-8") as f:
        f.write(script)

def format_mem(file_name):
    if not os.path.exists(file_name): return
    with open(file_name, "r", encoding="utf-8") as f:
        lines = f.readlines()
    with open(file_name, "w", encoding="utf-8") as f:
        for line in lines:
            if line.startswith('@') or not line.strip(): 
                f.write(line)
            else:
                words = line.strip().split()
                f.write(" ".join([w[6:8]+w[4:6]+w[2:4]+w[0:2] if len(w)==8 else w for w in words]) + "\n")

def run_vivado_headless():
    if os.path.exists(RTL_SIG_FILE): os.remove(RTL_SIG_FILE)
    tcl_safe_path = PROJECT_PATH.replace("\\", "/")
    
    tcl_script = f"""
open_project {tcl_safe_path}
set_property top tb_RV32I_Core_v1_debug [get_filesets sim_1]
update_compile_order -fileset sim_1
reset_simulation -simset sim_1 -mode behavioral
launch_simulation
run all
close_project
"""
    with open("run_sim.tcl", "w", encoding="utf-8") as f: 
        f.write(tcl_script)
        
    cmd = [VIVADO_CMD, "-mode", "batch", "-source", "run_sim.tcl", "-nolog", "-nojournal"]
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        return False, "Vivado 타임아웃 (60초)"
    
    if res.returncode != 0 or not os.path.exists(RTL_SIG_FILE):
        return False, "Vivado 시뮬레이션 에러"
    return True, ""

def process_test(asm_file, env_dir):
    test_name = os.path.basename(asm_file)
    print(f"\n[{test_name}] 테스트 진행 중...", flush=True)
    
    # 1. GCC 컴파일
    cmd_gcc = wrap_cmd([
        "riscv64-unknown-elf-gcc", "-x", "assembler-with-cpp", "-march=rv32i", "-mabi=ilp32", "-nostdlib", 
        f"-I{wsl_path(env_dir)}/p", f"-I{wsl_path(env_dir)}", "-I.", 
        "-T", "link.ld", wsl_path(asm_file), "-o", "test.elf"
    ])
    res_gcc = subprocess.run(cmd_gcc, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res_gcc.returncode != 0: return f"FAIL (컴파일 에러: {res_gcc.stderr.strip()})"
    
    # 2. RTL을 위한 메모리 추출
    subprocess.run(wrap_cmd(["riscv64-unknown-elf-objcopy", "-O", "verilog", "-j", ".text", "--change-section-address", ".text=0", "--verilog-data-width=4", "test.elf", "program_por.mem"]), check=True)
    subprocess.run(wrap_cmd(["riscv64-unknown-elf-objcopy", "-O", "verilog", "-j", ".data", "--change-section-address", ".data=0", "--verilog-data-width=4", "test.elf", "data_por.mem"]), check=True)
    
    format_mem("program_por.mem")
    format_mem("data_por.mem")
                
    # 3. Spike 구동 (Golden Model)
    cmd_spike = wrap_cmd(["spike", "--isa=rv32i", "-m0x80000000:0x10000", "--pc=0x80000000", "+signature=spike_sig.mem", "test.elf"])
    try:
        subprocess.run(cmd_spike, check=True, capture_output=True, text=True, encoding='utf-8', timeout=5.0)
    except subprocess.CalledProcessError as e: 
        return f"FAIL (Spike 실행 에러: {e.stderr.strip()})"
    except subprocess.TimeoutExpired:
        return f"FAIL (Spike 무한루프 타임아웃)"
    except Exception as e: 
        return f"FAIL (Spike 기타 시스템 에러: {str(e)})"
    
    print(f"  -> Vivado 백그라운드 시뮬레이션 실행 중...", flush=True)
    
    # 4. Vivado 구동 (RTL)
    success, err_msg = run_vivado_headless()
    if not success: return f"FAIL ({err_msg})"
    
    # 5. 결과 대조 (Bit-True Comparison) 및 정제
    gold_words, rtl_words = [], []
    try:
        with open("spike_sig.mem", 'r', encoding="utf-8") as f:
            for line in f:
                if line.strip(): 
                    chunks = [line.strip()[i:i+8] for i in range(0, len(line.strip()), 8)]
                    chunks.reverse()
                    gold_words.extend(chunks)
    except: return "FAIL (Spike Sig 누락)"
                
    try:
        with open(RTL_SIG_FILE, 'r', encoding="utf-8") as f:
            for line in f:
                line = line.strip().lower()
                # Vivado가 출력한 주소(@...)는 버리고 순수 데이터만 추출하며, 'x'는 '0'으로 패딩
                if line and not line.startswith('@'):
                    rtl_words.append('00000000' if 'x' in line else line)
    except: return "FAIL (RTL Sig 누락)"

    # 💡 [핵심 추가] RISC-V 공식 양식에 맞춰 제출용 폴더에 .signature.output 생성
    test_base_name = test_name.replace('.S', '')
    submit_sig_path = os.path.join(SUBMISSION_DIR, f"{test_base_name}.signature.output")
    
    try:
        with open(submit_sig_path, 'w', encoding="utf-8") as sf:
            for word in rtl_words:
                sf.write(word + "\n")
    except Exception as e:
        print(f"  -> [경고] 제출 파일 쓰기 실패: {str(e)}")

    # Bit-True Comparison 수행
    compare_len = len(gold_words)
    for i in range(compare_len):
        g_val, r_val = gold_words[i].lower(), rtl_words[i].lower()
        if g_val.lstrip('0') != r_val.lstrip('0'):
            return f"FAIL (Word {i} 불일치: Spike={g_val}, RTL={r_val})"
    return "PASS"


if __name__ == "__main__":
    print("==================================================", flush=True)
    print("🚀 RISC-V RV32I Official Compliance Runner & Packager", flush=True)
    print("==================================================", flush=True)
    
    # 제출용 폴더 생성 (없으면 생성)
    os.makedirs(SUBMISSION_DIR, exist_ok=True)
    print(f"📂 결과물 저장 경로: {SUBMISSION_DIR}", flush=True)
    
    create_compliance_headers()
    generate_linker_script()
    test_files, env_dir = find_test_environment(REPO_DIR)
    
    if not test_files: sys.exit(1)
    
    # 💡 컴파일러 버그가 입증된 I-MISALIGN_JMP 제외 및 알파벳 순 정렬
    target_files = sorted([f for f in test_files if "I-MISALIGN_JMP" not in f])
    
    results = {}
    passed = 0
    start_time = time.time()
    
    for asm in target_files:
        res = process_test(asm, env_dir)
        results[os.path.basename(asm)] = res
        if res == "PASS": passed += 1
        print(f"  -> 결과: {res}", flush=True)
        
    print("\n==================================================", flush=True)
    print("📊 [최종 공식 인증 리포트]", flush=True)
    print("==================================================", flush=True)
    for test, res in results.items():
        icon = "✅" if res == "PASS" else "❌"
        print(f"{icon} {test.ljust(20)} : {res}", flush=True)
    print("--------------------------------------------------", flush=True)
    print(f"총 {len(target_files)}개 테스트 중 {passed}개 PASS. (소요시간: {time.time()-start_time:.1f}초)", flush=True)
    
    if passed == len(target_files):
        print("\n🎉 [축하합니다!] 모든 시그니처 파일이 공식 양식으로 추출되었습니다.", flush=True)
        print(f"👉 제출용 폴더({SUBMISSION_DIR})를 압축하여 제출하십시오.", flush=True)