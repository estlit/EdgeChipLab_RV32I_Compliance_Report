# 🚀 RISC-V RV32I Compliance Report: EdgeChipLab_CPU_v1

**[🔗 View Core Architecture Diagram (PDF)](docs/Top_Block_Diagram.pdf)**

## 📌 1. Target Specifications
- **Target Name** : EdgeChipLab_CPU_v1
- **Device Type** : RTL (Verilog HDL) / FPGA Target Implementation
- **ISA String** : RV32I (Base Integer Instruction Set, 32-bit)
- **Extensions Supported** : None (Pure RV32I, No C-Extension)
- **Privilege Levels** : Machine Mode (M-Mode) Only
- **Simulation Platform** : Xilinx Vivado Simulator (xsim) 2023.1
- **Reference Model** : Spike (RISC-V ISA Simulator)
- **Verification Type** : 100% Bit-True Core Regression Test

---

## 📂 2. Repository Structure

This repository contains the full automated verification environment, architectural documentation, and official signature outputs.

```text
EdgeChipLab_RV32I_Compliance_Report/
 ├── README.md                      # This file (Target Info & Report)
 ├── doc/                          
 │    └── Top_Block_Diagram.pdf     # Top-level architecture schematic (PDF)
 ├── submission_results/            # Official RISC-V signature outputs
 │    ├── I-MISALIGN_JMP-01.WAIVER.txt
 │    ├── I-ADD-01.signature.output
 │    ├── I-SUB-01.signature.output
 │    └── ... (Total 48 files)
 └── verification_env/              # Automated testing scripts & headers
      ├── run_compliance.py         # 100% automated Vivado/Spike runner
      ├── compliance_model.h        # Target-specific macros
      ├── compliance_test.h
      ├── compliance_io.h
      └── link.ld                   # Memory map configuration